using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DetectCollisions : MonoBehaviour
{
    public bool farmAnimalCheck ;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    void OnTriggerEnter(Collider other)
    {
        if (farmAnimalCheck==false)
        {
            Debug.Log("Game Over!");
        }
        Destroy(gameObject);
        Destroy(other.gameObject);
    }
}
